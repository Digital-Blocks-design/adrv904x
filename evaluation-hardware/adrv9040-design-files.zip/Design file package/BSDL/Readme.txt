The ADRV904x pads that are user controllable for either CMOS or LVDS operation have been grouped per function and during JTAG testing it is assumed all members of the group will be configured as LVDS or CMOS (no mixing is allowed).   
This grouping implies 2 unique product configurations that are supported for JTAG test. 2 unique BSDL files are provided, one per configuration. 

The table below gives the JTAG mode and values to be used for each combination of IO_gpio[2:0] pins.

	I_Test_En	IO_GPIO_2	IO_GPIO_1	IO_GPIO_0
CMOS	1		0		0		0
LVDS	1		0		0		1

Please refer user guide UG-2192 for more details.