Design file package contains the following

Schematic and BOM : Contains the three match Low band , Midband amd high band schematics and BOM 
Layout : Contains Gerber files ,board file and board viewer.
S-parameter : Contains S parameter files for RF ports
IBIS_AMI : Contains IBIS AMI model for serdes simulation
BSDL : Boundary scan files
Footprint and symbol
